import { Actividades } from "./actividades";


export const ACTIVIDADES: Actividades[]=[

        {
           
            "actividades": [
                {"tarea": "Diseñar la base de datos", "estado": "Completo"},
                {"tarea": "Implementar API para el manejo de inventario", "estado": "En progreso"}
            ]
        },
        {
         
            "actividades": [
                {"tarea": "Diseñar interfaz de usuario", "estado": "En progreso"},
                {"tarea": "Implementar funcionalidades de la interfaz", "estado": "Pendiente"}
            ]
        },
        {
          
            "actividades": [
                {"tarea": "Configurar servidores", "estado": "Completo"},
                {"tarea": "Automatizar despliegues", "estado": "En progreso"}
            ]
        },
        {
         
            "actividades": [
                {"tarea": "Diseñar casos de prueba", "estado": "En progreso"},
                {"tarea": "Ejecutar pruebas automatizadas", "estado": "Pendiente"}
            ]
        }
    ]
}



  ]