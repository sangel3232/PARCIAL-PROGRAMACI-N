export class Tareas {
    id:number;
    nombreTarea: string;
    estado: string;
    vencimiento:string;
}
