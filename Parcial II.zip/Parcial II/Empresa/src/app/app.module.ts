import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule, Routes } from '@angular/router';
import { EquiposComponent } from './equipos/equipos.component';
import { ActividadesComponent } from './actividades/actividades.component';
//configuración de enrutamiento
const routes:Routes = [
  {path:'', redirectTo:'/equipos', pathMatch:'full'},
  {path:'actividades', component:ActividadesComponent},
  {path:'equipos', component:EquiposComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    EquiposComponent,
    ActividadesComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
