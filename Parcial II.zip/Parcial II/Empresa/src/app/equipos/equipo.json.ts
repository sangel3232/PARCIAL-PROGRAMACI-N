import { Equipo } from "./equipo";

export const EQUIPOS: Equipo[]=[
    {
        nombre: "Juan",
        apellido: "Pérez",
        rol: "Desarrollador Backend",
        lenguaje_programacion_favorito: "Python",
        nombre_proyecto: "Sistema de Gestión de Inventario"
        
    {
        nombre: "Maria",
        apellido: "Gomez",
        rol: "Desarrolladora Frontend",
        lenguaje_programacion_favorito: "JavaScript",
        nombre_proyecto: "Sistema de Gestión de Inventario"
        
    },
    {
        nombre: "Carlos",
        apellido: "Martínez",
        rol: "Ingeniero de DevOps",
        lenguaje_programacion_favorito: "Go",
        nombre_proyecto: "Sistema de Gestión de Inventario"
        
    {
        nombre: "Ana",
        apellido: "López",
        rol: "Analista de QA",
        lenguaje_programacion_favorito: "Java",
        nombre_proyecto: "Sistema de Gestión de Inventario"
       
            
    }
        ]

    
