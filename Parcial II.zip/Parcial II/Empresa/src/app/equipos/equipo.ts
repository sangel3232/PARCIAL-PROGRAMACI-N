export class Equipo {
    nombre: string;
    apellido: String;
    rol: String;
    lenguaje_programacion_favorito: String;
    nombre_proyecto: String;
    actividades: String
}
