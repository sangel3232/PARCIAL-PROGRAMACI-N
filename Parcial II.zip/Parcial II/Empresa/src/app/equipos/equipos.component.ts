import { Component, OnInit } from '@angular/core';
import { Equipo } from './equipo';
import { EquiposService} from './equipos.service';

@Component({
  selector: 'app-equipos',
  templateUrl: './equipos.component.html',
  styleUrls: ['./equipos.component.css']
})
export class EquiposComponent implements OnInit {
  
  equipos: Equipo[];

  constructor(private equiposService: EquiposService){}
  
  ngOnInit(): void {
    this.equiposService.getEquipoDos().subscribe(
      equipos => this.equipos = equipos
    );
  }

}
