import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Equipo } from './equipo';
import { EQUIPOS} from './equipo.json';

@Injectable({
  providedIn: 'root'
})
export class EquiposService {

  constructor() { }

  getEquipoDos():Observable<Equipo[]>{
    return of(EQUIPOS);
  }
}
